package Heap;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Huffman {
    HashMap<Character, String> encoder;
    HashMap<String, Character> decoder;

    class Node implements Comparable<Node>{
        Character data;
        int cost;
        Node right;
        Node left;

        Node(Character data, int cost) {
            this.data = data;
            this.cost = cost;
            this.right = null;
            this.left = null;
        }

        @Override
        public int compareTo(Node other){
            return this.cost - other.cost;
        }
    }

    public Huffman(String feeder){
        HashMap<Character, Integer> frequencyMap = new HashMap<>();

        for (int i = 0; i < feeder.length(); i++) {
            char c = feeder.charAt(i);

            if (frequencyMap.containsKey(c)){
                int ov = frequencyMap.get(c);
                ov++;
                frequencyMap.put(c,ov);
            }
            else {
                frequencyMap.put(c,1);
            }
        }

        HeapEx<Node> minHeap = new HeapEx<>();
        Set<Map.Entry<Character,Integer>> entrySet = frequencyMap.entrySet();

        for(Map.Entry<Character,Integer> entry : entrySet){
            Node node = new Node(entry.getKey(), entry.getValue());
            minHeap.insert(node);
        }

        while (minHeap != null){
            Node first = minHeap.remove();
            Node second = minHeap.remove();

            Node newNode = new Node('\0', first.cost+second.cost);
            newNode.left = first;
            newNode.right = second;

            minHeap.insert(newNode);
        }

       // Node fullTree = minHeap.remove();

        this.encoder = new HashMap<>();
        this.decoder = new HashMap<>();

       // this.initEncoderDecoder(fullTree, "");
    }

    private void initEncoderDecoder(Node node, String output) {
        if (node == null){
            return;
        }

        if (node.left == null && node.right == null){
            this.encoder.put(node.data, output);
            this.decoder.put(output, node.data);
        }
        initEncoderDecoder(node.left, output+"0");
        initEncoderDecoder(node.right,output+"1");
    }

    private String encode(String source){
        String ans = "";

        for (int i = 0; i < source.length(); i++) {
            ans += encoder.get(source.charAt(i));
        }
        return ans;
    }

    private String decode(String codedString){
        String key = "";
        String ans = "";
        for (int i = 0; i < codedString.length(); i++) {
            key += codedString.charAt(i);
            if(decoder.containsKey(key)){
                ans += decoder.get(key);
                key = "";
            }
        }
        return ans;
    }

    public static void main(String[] args) {
        String str = "abbccda";
        Huffman hf = new Huffman(str);
        String cs = hf.encode(str);
        System.out.println(cs);
        String dc = hf.decode(str);
        System.out.println(dc);
    }
}
